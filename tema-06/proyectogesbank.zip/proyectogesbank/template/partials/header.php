<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h4 class="display-7">Gestión Bancaria - GESBANK </h4>
            <p class="lead">Proyecto tema 6 - PHP y MYSQL</p>
        </div>
        </div>
    </hgroup>
</header>