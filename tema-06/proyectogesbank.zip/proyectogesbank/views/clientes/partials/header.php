<header class="pb-3 mb-4 border-bottom">
    <div class="container">
        <h4 class="display-7">Tabla Clientes </h4>
        <p class="lead">Proyecto tema 6 - PHP y MYSQL</p>
    </div>
</header>