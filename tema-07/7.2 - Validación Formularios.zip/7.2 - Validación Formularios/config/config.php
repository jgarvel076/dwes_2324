<?php
# Ruta 
define('URL', 'http://localhost/DWES/Tema07/Proyectos/7.2%20-%20Validación%20Formularios/');

define('HOST', 'localhost');
define('DB', 'fp');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');

?>