<?php 

    // Controlador: nuevo.php

    // Descripción: permite eliminar un elemento de la tabla

    # Librería
    require_once ('libs/crud_funciones.php');

    # Model
    require_once ('models/modelNuevo.php');

    # View
    require_once ('views/viewNuevo.php');

?>