<?php 

    // Cargamos libreria
    include 'libs/crud_funciones.php';

    //Cargamos modelo
    include "models/modelIndex.php";

    //Cargamos vista
    include "views/viewIndex.php";
    
?>