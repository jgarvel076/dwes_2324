<?php 

    # Cargamos modelo 
    include "models/modelIndex.php";
    include "models/modelBuscar.php";

    # Cargamos vista
    include "views/viewIndex.php";

?>