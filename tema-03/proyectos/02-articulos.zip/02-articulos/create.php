<?php 

    // Cargamos librería
    include 'libs/crud_funciones.php';

    // Cargamos modelo
    include 'models/modelCreate.php';

    // Cargamos vista
    include 'views/viewIndex.php';

?>