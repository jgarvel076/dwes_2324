<?php 

    // Cargamos libreria 
    include "libs/crud_funciones.php";

    // Cargamos el modelo
    include "models/modelMostrar.php";

    // Cargamos la vista 
    include "views/viewMostrar.php";

?>