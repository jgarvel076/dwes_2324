<?php 

    // Librerias
    include 'libs/crud_funciones.php';

    // Cargamos modelo 
    include 'models/modelEditar.php';

    // Cargamos vista
    include 'views/viewEditar.php';

?>