<?php 


    generar_Tabla();

?>