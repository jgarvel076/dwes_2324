<?php
# Configuración básica aplicación MVC

# Ruta absoluta
//define('URL', 'http://localhost/DWES/dwes_2324/tema-13/proyecto/proyectofinal/');
define('URL', 'http://localhost/DWES/tema-13\proyecto\proyectofinal/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>