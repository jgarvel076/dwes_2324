<?php 

    include 'class/class.jugador.php';
    include 'class/class.arrayJugadores.php';

    include 'models/model.create.php';

    include 'views/view.index.php';

?>