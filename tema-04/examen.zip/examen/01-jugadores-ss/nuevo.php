<?php 

    // Controlador: nuevo.php

    # Clases
    include 'class/class.jugador.php';
    include 'class/class.arrayJugadores.php';

    # Model
    include 'models/model.nuevo.php';

    # View
    include 'views/view.nuevo.php';

?>