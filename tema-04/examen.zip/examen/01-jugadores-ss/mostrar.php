<?php 

    include "class/class.jugador.php";
    include "class/class.arrayJugadores.php";

    include "models/model.mostrar.php";
 
    include "views/view.mostrar.php";

?>