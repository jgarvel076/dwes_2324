<?php

$posiciones = tablaJugadores::getPosiciones();
$equipos = tablaJugadores::getEquipos();
$paises = tablaJugadores::getPaises();

?>