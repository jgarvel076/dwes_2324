<?php

$posiciones = tablaJugadores::getPosiciones();
$equipos = tablaJugadores::getEquipos();
$paises = tablaJugadores::getPaises();
$jugadores->getDatos();

$idBuscado = $_GET['indice'];

?>