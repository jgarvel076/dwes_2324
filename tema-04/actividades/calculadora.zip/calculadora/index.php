<?php

#Clase calculadora
include("class/class.calculadora.php");

#Cargo el modelo

#Cargo la vista
include("views/view.index.php");


?>