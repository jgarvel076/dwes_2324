<?php
# Configuración básica aplicación MVC

# Ruta absoluta

define('URL', 'http://localhost/dwes_2324/proyectorecuperacion/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gescomercial');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>