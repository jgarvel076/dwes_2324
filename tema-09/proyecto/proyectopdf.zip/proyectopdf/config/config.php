<?php
# Configuración básica aplicación MVC

# Ruta absoluta
//define('URL', 'http://localhost/DWES/dwes_2324/tema-09/proyecto/proyectopdf/');
define('URL', 'http://localhost/DWES/tema-09/proyecto/proyectopdf/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>